#include<stdio.h>

int getfirstdayoftheyear(int year)
{
    int day = (year * 365+ ((year -1)/4) - ((year - 1)/100) + ((year -1)/400) ) %7;
    return day;
}
int main()
{
    char *months[]={"January", "February", "March", "April", "May", "June", "July" , "August","September", "October", "November","December"   };
    int daysmonth[]={31, 28,31, 30,31,30,31,31,30, 31,30,31} ;

    int i,j,totaldays,weekday=0,spacecounter=0,year;
    printf("Enter your favourite year:  \n");
    scanf("%d", &year);
    printf("\n\n*****************wellcome to the year of %d****************\n\n\n", year);

//leapyear
    if ((year % 4==0  && year%100!=0) || (year %400==0))
    {
        daysmonth[1]=29;
    }
 //firstdayofthe year
    weekday=getfirstdayoftheyear(year);

    for(i=0; i<12; i++)
    {
        printf("\n\n\n========================%s=======================\n", months[i]);
        printf("\n   sun   mon   tue   wed   the   fri   sat   \n");

        for(spacecounter=1; spacecounter<=weekday; spacecounter++)
        {
            printf("      ");
        }
        totaldays=daysmonth[i];
        for(j=1; j<=totaldays; j++)
        {
            printf("%6d", j);
            weekday++;
            if(weekday>6)
            {
                weekday=0;
                printf("\n");
            }
        }
    }
    return 0;
}


