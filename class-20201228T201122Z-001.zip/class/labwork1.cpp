#include <iostream>
#include<string.h>

using namespace std;

int main()
{
    int check=0;                
    int i=0;                    

    
    string str;       
    getline(cin, str);

    while(str[i]){                      
        if(check==0){
            str[i]=toupper(str[i]);     
            check=1;
        }else if(isspace(str[i]))       
            check=0;
        i++;
    }
    cout<< str <<endl;
    return 0;
}
