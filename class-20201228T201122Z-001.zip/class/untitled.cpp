
#include <bits/stdc++.h>
#include<cmath>
#include<string>
using namespace std;
int main()
{
    int check=0;                
    int i=0;                    
    
    string a[100];
    getline(cin, a); 
    
    while(a[i]){                      
        if(check==0){
            str[i]=toupper(a[i]);     //conversion of string takes place here
            check=1;
        }else if(isspace(a[i]))       // change status of check if move to another word
            check=0;
        i++;
    }
    cout<<"Processed string: "<<a<<endl;
    return 0;
}
