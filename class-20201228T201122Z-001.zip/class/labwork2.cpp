#include<bits/stdc++.h>
#include<string>
#include<algorithm>
using namespace std;

bool anagram( string A, string B)
{
	int n1, n2, i;
	n1=A.length();
	n2=B.length();
	
	if(n1 != n2)
	return false;
	sort(A.begin(), A.end());
	sort(B.begin(), B.end());
	
	for(i=0; i<n1; i++)
	{
		if(A[i] != B[i])
		return false;
	}
	return true;
	
}
int main()
{
	string a;
	string b;
	cout << "Enter the 1st string: " ;
	getline(cin, a);
	cout << "Enter the 2nd string: " ;
	getline(cin, b);
	
	if(anagram(a,b))
	cout << quoted (a)<<"is an Anagram of" << quoted (b) << endl;
	
	else
	cout<< "this two string are not anagram" ;
	
	
	return 0;
	
	
	
}
