#include<bits/stdc++.h>
using namespace std;

int main()
{
	string s;
	getline(cin, s);
	int i;
	for(i=0; s[i]; i++){
		if(i==0)
		{
			if(s[i]>='a' && s[i]<='z')
			{
				s[i]= s[i] - 32;
				cout << s[i];
			}
		}
		else if ( s[i-1] == ' ')
		{
			if(s[i]>='a' && s[i]<='z')
			{
				s[i]= s[i] - 32;
				cout << s[i];
			}
		}
		
		else{
		i++;
                if(islower(s[i]))
                    s[i]=toupper(s[i]);
		cout << s[i];}
		
	}
	
	return 0;
}	
			
