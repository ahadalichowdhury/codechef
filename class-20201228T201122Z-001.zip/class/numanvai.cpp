void linklist :: insert(int value)
{
	node* p=new node;
	p->data = value;
	p->next = head;
	head=p;
	cout<< value << "is inserted"<< endl;
	
}

void linklist :: deletefrombeg()
{
	if(head == NULL)
	{
		cout<< "the list is empty";
	}
	node* P;
	head= head->next;
	int data= p->data;
	delete p;
	cout<< data << "is deleted from beg" << endl;
	
}




void linklist :: insertatend(int data)
{
	node* p=new node;
	p->data = data;
	p->next = NULL;
	
	node* r= head;
	if(r==NULL)
	{
		head= p;
		
	}
	else{
		while(r-> next!=NULL)
		{
			r = r->next;
			}
		}
		cout<< data << " is inserted the end" << endl;
	
}

void LinkedList :: deleteFromEnd()
{
    if(head == NULL)
    {
        cout << "List is empty." << endl;
        return;
    }

    Node *n = head;
    if(n->next == NULL) /// the list contains only 1 node
    {
        int data = n->data;
        head = NULL;
        delete n;
        cout << data << " deleted from the end." << endl;
        return;
    }

    Node *s; /// previous node of n
    while(n->next != NULL)
    {
        s = n;
        n = n->next;
    }
    s->next = NULL;

    int data = n->data;
    delete n;
    cout << data << " is deleted from the end." << endl;
}

void LinkedList :: insertAtLoc(int loc, int data)
{
    if(loc == 1)
    {
        insertAtBeginning(data);
        return;
    }

    Node *p = new Node;
    p->data = data;

    Node *r = head; /// head is at loc#1
    for(int i=2; i<loc; i++)
    {
        r = r->next;
    }
    Node *s = r->next;
    r->next = p;
    p->next = s;

    cout << data << " is inserted at location " << loc << endl;
}

void LinkedList :: deleteFromLoc(int loc)
{
    if(loc == 1)
    {
        deleteFromBeginning();
        return;
    }

    Node *r = head;
    for(int i=2; i<loc; i++)
    {
        r = r->next;
    }
    Node *s = r->next;
    Node *t = s->next;
    r->next = t;

    int data = s->data;
    delete s;
    cout << data << " is deleted from location " << loc << endl;
}




void linklist:: insertatend(int data)
{
node* P= new node;
p->data = data;
p->next = NULL;

node* r= head;
if (head == NULL)
{
	cout<< "the list is empty";
}
else
{
	while(r!= NULL)
	{
		r= r->next;
	}
	cout<< data << "is inserted in the list";
}

}


