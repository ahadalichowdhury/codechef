#include <bits/stdc++.h> 
using namespace std; 


 
int findMinDiff(int arr[], int N) 
{ 
  int X , Y;
  cin>>X>>Y;
  int min_dist ;
  int i = 0, j = 0; 
  while(i < N and j < N)
  {
    if(arr[i] == X)
      {
        while( j < N and arr[j] != Y) 
          j++;  
        if(j < N and arr[j] == Y)
        min_dist = min(min_dist,abs(i-j));
        
        i = j; 
      }
    else if(arr[i] == Y)
    {
        while( j < N and arr[j] != X)
          j++;
          
        if(j < N and arr[j] == X)
        min_dist = min(min_dist,abs(i-j));
      i = j;
    }
    else
     i++;
  }
  return min_dist;
  
}
  
 
int main() 
{   
	int N;
   cin>>N;
    int arr[N];
    for(int i=0;i<N;i++)
    {
        cin>>arr[i];
    }
   int n = sizeof(arr)/sizeof(arr[0]); 
   cout << "Minimum difference is " << findMinDiff(arr, n); 
   return 0; 
} 
