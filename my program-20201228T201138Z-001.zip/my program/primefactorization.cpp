#include<bits/stdc++.h>
using namespace std;

vector<int>prime;

int List[128]; 
int listSize; // saves the size of List
void primeFactorize( int n ) {
listSize = 0; // Initially the List is empty, we denote that size = 0
for( int i = 0; prime[i] <= n; i++ ) {
if( n % prime[i] == 0 ) { // So, n is a multiple of the ith prime
// So, we continue dividing n by prime[i] as long as possible
while( n % prime[i] == 0 ) {
n /= prime[i]; // we have divided n by prime[i]
List[listSize] = prime[i]; // added the ith prime in the list
listSize++; // added a prime, so, size should be increased
}
}
}
}
int main() {
primeFactorize( 40 );
for( int i = 0; i < listSize; i++ ) // traverse the List array
printf("%d ", List[i]);
return 0;
}
