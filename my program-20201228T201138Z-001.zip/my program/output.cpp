#include<bits/stdc++.h>
using namespace std;
int main()
{
	string s1= "1", s2="2", s3;
	s1=s1+s1+s1;
	cout<< s1<< endl;;
	
	s3= s1+s2;
	
	cout<< s3<< endl;
	cout<< (s1<s2) << endl;
	
}
//OUTPUT->>   111
			//1112
			//1
