#include<bits/stdc++.h>
using namespace std;

typedef long long ll;

ll bigMod(ll base, ll power, ll mod)
{
	if(power ==0)
	return 1;
	
	else if(power%2==1)//for odd number
	{
		int a= base % mod;// (2^3)-> 2^1 er jonno
		int b= bigMod(base, power -1,mod) % mod;// (2^3)-> 2^2 er jonno
		return (a*b)% mod;
	}
	
	else if(power%2==0)//for even number
	{
		int a= (bigMod (base, power/2, mod))%mod;//2^4->(2^2)^2
		return (a*a)% mod;
	}
}

int main()
{
	ll base, power, mod;
	cin>> base>> power>> mod;
	cout<< bigMod(base, power, mod)<< endl;
	
}

