#include<bits/stdc++.h>
using namespace std;
int main()
{
	stack<string>s;
	s.push("Numan");
	s.push("ataur Rahman");
	s.push("ahad chowdhury");
	
	while(!s.empty())
	{
		string x;
		x=s.top();
		cout<< x<< endl;
		s.pop();
		
	}
}
