#include<bits/stdc++.h>
using namespace std;
int gcd(int a, int b)
{
	return (b==0) ? a: (b, a%b);
}
int lcm(int a, int b)
{
	return (a/gcd(a,b))*b;
}
int main()
{
	int s=gcd(20, 40);
	cout<< s<< endl;
	int t=lcm(3, 7);
	cout<< t<< endl;
	
}
