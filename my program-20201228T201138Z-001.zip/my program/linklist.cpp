#include<bits/stdc++.h>
using namespace std;

struct Node{
    int data;
    struct Node* link;
};
struct Node* head;

int print()
{
    struct Node * temp;
    temp= head;
    while(temp!= NULL)
    {
        cout<< temp->data << endl;
           temp=temp-> link;
    }
}

void insertinbig(int value)
{
	struct Node* temp;
	temp=(struct Node* )malloc (sizeof(struct Node));
	temp->data=value;
	temp->link=head;
	head=temp;
}

void insert(int value)
{
	struct Node * temp;
	temp=(struct Node*)malloc(sizeof(struct Node));
	temp->data=value;
	temp->link=NULL;
	if(head== NULL)
	{
		head=temp;
		
	}
	else
	{
		struct Node* t;
		t=head;
		while(t->link != NULL)
		{
			t=t->link;
		}
		t->link = temp;
	}
	
}

void deleteposition(int position)
{
	if(position==1)
	{
		struct Node* temp;
		temp=head;
		head=head->link;
		free(temp);
		
	}
	else
	{
		struct Node* temp1;
		temp1=head;
		for(int i=1; i<=position -2; i++)
		{
			temp1=temp1 ->link;
		}
		struct Node* temp2;
		temp2=temp1->link;
		temp1->link= temp2->link;
	}
}
int main()
{
    head= NULL;
    insert(4);
    insert(5);
    insert(6);
    
    insertinbig(3);
    insertinbig(2);
    insertinbig(1);

    
    
    print();
    
    deleteposition(4);
    print();
}

