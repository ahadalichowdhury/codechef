#include<bits/stdc++.h>
using namespace std;
#define MAX 100000

bool a[MAX];

void seive(int);


int main()
{
    int n;

    cout << "Enter range: ";
    cin >> n;

    seive(n);

    cout << "List of primes from 1 to " << n << ":" << endl;
    for(int i=1; i<=n; i++)
    {
        if(a[i] == true)
            cout << i << "\t";
    }
    cout << endl;

    return 0;
}

void seive(int n)
{
    int i, j, k;

    for(i=2; i<=n; i++)
        a[i] = true;// true means prime number

    for(i=2, j=sqrt(n); i<=j; i++)
    {
        if(a[i] == true) {
            for(k=i+i; k<=n; k+=i)
                a[k] = false;
        }
    }
}
 
