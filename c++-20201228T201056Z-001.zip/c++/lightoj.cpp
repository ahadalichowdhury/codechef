#include<bits/stdc++.h>
using namespace std;
int main()
{
	int i,j,t;
	int n,s,x,y;
	
	cin>>i;
	for(j=1; j<=i; j++)
	{
		cin>> s;
		n=ceil(sqrt(s));
		if(n*n-s < n)
		{
			x=n;
			y=n*n-s+1;
		}
		else
		{ 
		x=-n*n+2*n+s-1,y=n;
		}
		if(n&1)
        {
            t=x;
            x=y;
            y=t;
        }
        cout<< "Case " << j <<": " << x<<" " << y<< endl;
		
		
		
	}
	
	return 0;
	
