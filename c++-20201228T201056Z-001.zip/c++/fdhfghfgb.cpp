#include<bits/stdc++.h>

using namespace std;

void sort_elements(int a [], int num_elements)
{
	int i = 0;
	int j= num_elements  - 1;
	
	while(i<j)
	{
		int leftelement = a[i];
		int rightelement = a[j];
		
		if(leftelement == 0)
		{
			i++;
			}
		if(rightelement == 1)
		{
			j--;
		}
		
		if(leftelement == 1 && rightelement ==0)
		{
			a[i] = rightelement;
			a[j] = leftelement;
			i++;
			j--;
			
			
		}
		
		
			
		
		
		
		
		
	}
	
	
	
	
	
}

int main() 

{ 
    int a[] = { 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0}; 
     int num_elements = sizeof(a) / sizeof(a[0]); 
       
      
    sort_elements(a, num_elements); 
     
  
    for (int k = 0; k < num_elements; k++) 
        cout << a[k] << " "; 
    
      
    return 0; 

	
	
	
	
}
