#include<bits/stdc++.h>
using namespace std;

struct node{
	int data;
	node* next;
	
	};
	
struct linklist{
	node* head;
	linklist();  //constructor
	~linklist(); // destructor
	void display();
	void insert(int data);
	};
	
void linklist :: display()
{
    cout << "The list is: ";
    if(head == NULL)
    {
        cout << "empty" << endl;
        return;
    }

    node *t = head;
    while(t != NULL)
    {
        cout << t->data << " -> ";
        t = t->next;
    }
    cout << "NULL" << endl ;
}

	
linklist :: linklist()
{
	head=NULL;
}

linklist ::~linklist()
{
	node* t;
	while(head != NULL)
	{
		t=head->next;
		delete head;
		head=t;
	}
}
void linklist :: insert(int value)
{
	node* p = new node;
	p->data = value;
	p->next = head;
	head= p;
	cout<< value << "is inserted in list" << endl;
	
}
	
int main()
{	
	linklist mylist;
	mylist.insert(10);
	mylist.insert(15);
	mylist.display();
	return 0;
}
                  
