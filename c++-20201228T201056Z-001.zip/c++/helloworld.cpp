#include<bits/stdc++.h>
using namespace std;
int main()
{
	int magic[99][99];
	int size;
	cout<< "Enter the size: ";
	cin >> size;
	int start = size/2;
	
	int max= size*size;
	magic [0][start]=1;
	int cur_r;
	int cur_c;
	int next_r;
	int next_c;
	int num;
	for(num=2, cur_r=0, cur_c=start; num<=max; num++)
	{
		if((cur_c +1) > (size -1 )){
			next_c=0;
		}
		else
        {
			next_c=cur_c+1;
		}
		if(cur_r-1 <0)
		{
			next_r=size - 1;
		}
		else
		{
			next_r=cur_r-1;
			
		}
		if(magic[next_r][next_c] > 0)
		{
			if(cur_r+1 > size - 1)
			{
				next_r=0;
			}
			else
			{
				next_r=cur_r+1;
				next_c = cur_c;
			}
			
		}
		cur_r=next_r;
		cur_c=next_c;
		magic[cur_r][cur_c]= num;	
			
		}
		int i,j;
		for(i=0; i<size; i++)
		{
			for(j=0; j<size; j++)
			{
				cout<< magic[i][j] << " ";
				
			}
			cout<< "\n";
		}
		
		
		
	
	return 0;
} 

