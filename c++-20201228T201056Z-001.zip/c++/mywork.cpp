#include<bits/stdc++.h>
using namespace std;

void sort_elements(int a [], int num_elements)
{
	int count=0;
	int i;
	
	for(i=0; i< num_elements; i++)
	{
		if(a[i]==0){
			count++;
		}
	}
	
	
	for (i=0; i< count; i++)
	{
		a[i]=0;
		
	}
	
	for(i=count; i<num_elements; i++)
	{
		a[i]=1;
		}
		
}
	




int main() 

{ 
    int a[] = {1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0}; 
     int num_elements = sizeof(a) / sizeof(a[0]); 
       
      
    sort_elements(a, num_elements); 
     
  
    for (int i = 0; i < num_elements; i++) 
        cout << a[i] << " "; 
    
      
    return 0; 

	
	
	
	
}
