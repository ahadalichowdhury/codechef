#include<bits/stdc++.h>
using namespace std;

struct node
{
	int data;
	node* next;
	
};

struct linklist
{
	node* head;
	
	linklist();
	~linklist();
	void insert(int data);
	void display();
	void insertatend(int data);
	void insertatloc(int loc, int data);
	void deletefrombeg();
	
	
	
};

void linklist :: insertatloc(int loc, int data)
{
	if(loc ==1)
	{
		insert(data);
		return; }
		node* p=new node;
		p->data=data;
		
		
		node* r =head;
		for(int i=0; i< loc; i++)
		{
			r= r->next;
		}
		node* s=r->next;
		r->next = p;
		p->next = s;
		
		cout<< data<< "is inserted in the location " << loc << endl;
		
		
}

void linklist :: insertatend(int data)
{
	node* p=new node;
	p->data = data;
	p->next = NULL;
	
	node* r= head;
	if(r==NULL)
	{
		head= p;
		
	}
	else{
		while(r-> next!=NULL)
		{
			r = r->next;
			}
		}
		cout<< data << " is inserted the end" << endl;
	
}
linklist:: linklist ()
{
	head = NULL;
	
}
linklist :: ~linklist()
{
	node* t;
	while(head!= NULL)
	{
		t= head->next;
		delete head;
		head=t;
		
	}
	
}
void linklist :: insert(int value)
{
	node* p=new node;
	p->data = value;
	p->next = head;
	head=p;
	cout<< value << "is inserted"<< endl;
	
}
void linklist:: display()
{
	cout<< "this list is";
	if(head == NULL)
	{
		cout<< "empty" << endl;
	}
	node* t=head;
	while(t!=NULL)
	{
		cout<< t->data<< "->";
		t= t->next;
	}
	cout<< "NULL" << endl;
	
}

void linklist :: deletefrombeg()
{
	if(head == NULL)
	{
		cout<< "the list is empty";
	}
	node* P;
	head= head->next;
	int data= p->data;
	delete p;
	cout<< data << "is deleted from beg" << endl;
	
}
int main()
{
	linklist mylist;
	mylist.insert(50);
	mylist.insert(20);
	mylist.display();
	return 0;
}

