#include<bits/stdc++.h>
using namespace std;
double getMean(double *a,double n)
{
    double sum=0.0;
    for(int i=0; i<n; i++)


        sum+= a[i];

    return (double)sum /(double)n;
}

double getMedian(double *a,double n)
{

    sort (a, a+10);

    if (10%2!=0)

        return (double) a[10/2];

    return (double) (a[(10-1)/2]+ a[10/2])/2.0;
}

double getMode(double *a,double n)
{

    sort (a, a+10);

    double max_count =1, res= a[0], count=1;

    for( int i=0; i<10; i++)
    {
        if (a[i]==a[i-1])
            count ++;
        else
        {
            if (count>max_count)
            {
                max_count =count;
                res=a[i-1];
            }
            count =1;
        }
    }
    if (count >max_count)
    {
        max_count=count;
        res=a[10-1];
    }
    return  res;
}
int main()
{
    double a[10]= {3.4, 4.8, 8.4, 9.6, 2.3, 9.6, 5.6, 9.6, 4.8, 2.2};
    double n=(a,10);

    cout << "Mean ="<<getMean(a,n)<<endl;
    cout << "Median ="<<getMedian(a,n)<<endl;
   cout << "Mode ="<<getMode(a,n)<<endl;
}
